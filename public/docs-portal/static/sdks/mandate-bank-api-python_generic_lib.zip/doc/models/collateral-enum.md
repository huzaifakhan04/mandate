
# Collateral Enum

## Enumeration

`CollateralEnum`

## Fields

| Name |
|  --- |
| `INVOICE_LINK` |
| `NONE` |

## Example

```python
from mandatebankapi.models.collateral_enum import CollateralEnum

collateral = CollateralEnum.INVOICE_LINK
```

