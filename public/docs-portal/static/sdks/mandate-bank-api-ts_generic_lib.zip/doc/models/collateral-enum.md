
# Collateral Enum

## Enumeration

`CollateralEnum`

## Fields

| Name |
|  --- |
| `InvoiceLink` |
| `None` |

## Example

```ts
import { CollateralEnum } from 'mandate-bank-apilib';

const collateral = CollateralEnum.InvoiceLink;
```

