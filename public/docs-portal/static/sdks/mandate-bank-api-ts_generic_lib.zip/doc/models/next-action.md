
# Next Action

## Structure

`NextAction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tool` | `string` | Required | - |
| `args` | `unknown` | Required | - |

## Example

```ts
import { NextAction } from 'mandate-bank-apilib';

const nextAction: NextAction = {
  tool: 'tool8',
  args: { 'key1': 'val1', 'key2': 'val2' },
};
```

